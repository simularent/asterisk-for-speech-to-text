The oauth2client is a client library for OAuth 2.0.


